# Blorm ton-connect/mint-bot
Jeff this is a Simple bot written on Python to interact with TON wallets using Ton Connect protocol for People to Mint Directly from Telegram
ive added the Smart contracts needed for this in email to Tint.eth sir 

### Redis
after testing we may need a permanent TON Connect storage you should [set up Redis](https://redis.io/docs/getting-started/) or any other database.


### Install dependencies:

```bash
pip install -r requirements.txt
```
Jeff make sure to Install the dependencies in Current Directory, not on /user/appdata/Roaming

### Set up `.env`: Ive already set up env with the bot token key to our telegram bot

```dotenv
TOKEN='7030677289:AAHjBUSbdJxbTLnRUbYA4OdbGLQQjWo0imM'  # this is our bot token
MANIFEST_URL='https://raw.githubusercontent.com/XaBbl4/pytonconnect/main/pytonconnect-manifest.json' !! make sure this is the same
```

### Run bot

```python
python3 src/main.py
```
link to the telegram bot - https://t.me/BlormBot

I've kept it as simple as i can, you can add your custom Functions as you want !

Cheers Mate Have a Great Day !!!!