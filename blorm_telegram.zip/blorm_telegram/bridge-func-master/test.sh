node test/change-collector.js &&
node test/change-fee.js &&
node test/change-fee-not-oracle.js &&
node test/change-state.js &&
node test/eth2ton.js &&
node test/get-reward.js &&
node test/index.js &&
node test/migrate.js &&
node test/ton2eth.js &&
node test/ton2eth-binary.js &&
node test/ton2eth-disabled.js &&
echo "OK"