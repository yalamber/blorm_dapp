```
link_cell {
     int32            //depth of reference
     cell             //at least 1 cell with a link
     {
       cell             
       cell             //maximum + 3 cells with links
       cell
     }
}
```
     
