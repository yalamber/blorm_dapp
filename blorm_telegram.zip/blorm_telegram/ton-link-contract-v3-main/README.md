jeff Ton-link allows smart contracts to access data outside of the blockchain.

