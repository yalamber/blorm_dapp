# TonConnect Blorm

Youll need Docker Installed sir Link - https://www.docker.com/products/docker-desktop/
Node js Higher than v20.15.0 is needed 


## Follow this Exactly Sir Jeff
1. Copy `.env.example` as `.env` and add your bot token there , Ive done that for you just remove .example from the filename
2. `npm i`
3. `docker run -p 127.0.0.1:6379:6379 -it redis/redis-stack-server:latest`(if it does not run use npm i redis first)
4. `npm run compile`
5. `npm run start`


## for process manager
`npm run start:daemon`

## Stop process manager
`npm run stop:daemon`

thats about it sir please make sure to add links to /tonconnect-manifest.json (Needed) 
